import React from 'react';
import { ScrollView, Text, StyleSheet } from 'react-native';

export default function TermsScreen() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Terms and Conditions</Text>
      <Text style={styles.content}>
        Capital 40 is a community contribution platform. All contributions are made voluntarily and at your own risk. No financial guarantees, returns, or payouts are promised or implied.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#121212', padding: 20 },
  title: { fontSize: 24, color: '#9b59b6', marginBottom: 10 },
  content: { fontSize: 16, color: '#eee' }
});
