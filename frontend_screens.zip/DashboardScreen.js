import React from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';

export default function DashboardScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Your Dashboard</Text>
      <Text style={styles.info}>Tier: Bronze</Text>
      <Button title="Contribute Now" onPress={() => {}} color="#9b59b6" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#1a1a1a' },
  header: { fontSize: 26, color: '#9b59b6', marginBottom: 20 },
  info: { fontSize: 18, color: '#fff', marginBottom: 20 }
});
