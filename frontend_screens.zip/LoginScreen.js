import React from 'react';
import { View, Text, StyleSheet, TextInput, Button } from 'react-native';

export default function LoginScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login to Capital 40</Text>
      <TextInput placeholder="Email" style={styles.input} placeholderTextColor="#ccc" />
      <TextInput placeholder="Password" style={styles.input} secureTextEntry placeholderTextColor="#ccc" />
      <Button title="Login" onPress={() => {}} color="#9b59b6" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#121212', justifyContent: 'center' },
  title: { fontSize: 24, color: '#fff', marginBottom: 20, textAlign: 'center' },
  input: { borderWidth: 1, borderColor: '#444', padding: 10, marginBottom: 15, color: '#fff', borderRadius: 5 }
});
