# Capital40 App

Full-stack app with secure backend and mobile frontend.